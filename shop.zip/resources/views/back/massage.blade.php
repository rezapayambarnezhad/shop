@if(session('success'))
<div class="alert alert-success" dir="rtl">
    {{session('success')}}
</div>
@endif
