<?php

namespace App\Http\Controllers\front;

use App\Article;
use App\category;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    public function index(Request $request){
        if($request->search==null)
            $msg='کلمه ای وارد نشد';
            return redirect()->back()->with('success',$msg);
        $articles=Article::get();
        $search=$request->search;
        $categories=category::get();
        $category_search=$request->category;
        foreach ($categories as $category){
            if($category->id==$category_search){
                $results=$category->articles()->get();

            }
        }
//        dd($result);
        if ($results){
            return view('front.search',compact('search','results'));
        }
        else{
            return view('front.search',compact('search','articles'));
        }



    }
}
