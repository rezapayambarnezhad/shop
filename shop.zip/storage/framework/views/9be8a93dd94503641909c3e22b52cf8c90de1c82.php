<header>
    <!-- top Header -->
    <div id="top-header">
        <div class="container">
            <div class="pull-left" >
                <span>Welcome to E-shop!</span>
            </div>
            <div class="pull-right">
                <ul class="header-top-links">

                    <li class="dropdown default-dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">ENG <i class="fa fa-caret-down"></i></a>
                        <ul class="custom-menu">
                            <li><a href="#">English (ENG)</a></li>
                            <li><a href="#">Russian (Ru)</a></li>
                            <li><a href="#">French (FR)</a></li>
                            <li><a href="#">Spanish (Es)</a></li>
                        </ul>
                    </li>

                </ul>
            </div>
        </div>
    </div>
    <!-- /top Header -->

    <!-- header -->
    <div id="header">
        <div class="container">
            <div class="pull-left">
                <!-- Logo -->
                <div class="header-logo">
                    <a class="logo" href="#">
                        <img src="<?php echo e(url('/img/logo.png')); ?>" alt="">
                    </a>
                </div>
                <!-- /Logo -->

                <!-- Search -->
                <div class="header-search">
                    <form action="<?php echo e(route('search')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input class="input search-input" type="text" placeholder="کلمه مورد نظر را وارد کنید" name="search" >
                            <select class="input search-categories" name="category">
                                <option value="0">همه دسته ها</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="search-btn" ><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
                <!-- /Search -->
            </div>
            <div class="pull-right" dir="rtl">
                <ul class="header-btns">
                    <!-- Account -->
                    <li class="header-account dropdown default-dropdown">
                        <div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
                            <div class="header-btns-icon">
                                <i class="fa fa-user-o"></i>
                            </div>
                            <?php if(auth()->guard()->check()): ?>
                            <strong class="text-uppercase"> <?php echo e(Auth::user()->name); ?> <i class="fa fa-caret-down"></i></strong>
                                <?php else: ?>
                                <strong class="text-uppercase"> منوی کاربری <i class="fa fa-caret-down"></i></strong>
                                <?php endif; ?>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                            <form id="myForm" action="<?php echo e(route('logout')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <a href="#"  onclick="myFunction()"> خروج </a>
                                
                            </form>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="text-uppercase">ورود</a> / <a href="<?php echo e(route('register')); ?>" class="text-uppercase">ثبت نام</a>
                        <?php endif; ?>

                        <ul class="custom-menu">
                            <?php if(auth()->guard()->check()): ?>
                            <li><a href="#"><i class="fa fa-user-o"></i> پنل کاربری </a></li>
                            <li><a href="<?php echo e(route('admin.index')); ?>"><i class="fa fa-user-circle-o"></i> پنل مدیریت</a></li>

                            <li><form id="myForm" action="<?php echo e(route('logout')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                               <a href="#"  onclick="myFunction()"><i style="color: #1ac0ac ;margin-right: 10%" class="fa fa-check"></i> خروج </a>

                                </form>
                            </li>

                                <?php else: ?>




                                <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-unlock-alt"></i>  ورود</a></li>
                                <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-plus"></i>  ثبت نام </a></li>
                            <?php endif; ?>

                        </ul>
                    </li>
                    <!-- /Account -->

                    <!-- Cart -->













                        <div class="custom-menu">
                            <div id="shopping-cart">
                                <div class="shopping-cart-list">
                                    <div class="product product-widget">
                                        <div class="product-thumb">
                                            <img src="./img/thumb-product01.jpg" alt="">
                                        </div>
                                        <div class="product-body">
                                            <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                            <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                        </div>
                                        <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                    </div>
                                    <div class="product product-widget">
                                        <div class="product-thumb">
                                            <img src="./img/thumb-product01.jpg" alt="">
                                        </div>
                                        <div class="product-body">
                                            <h3 class="product-price">$32.50 <span class="qty">x3</span></h3>
                                            <h2 class="product-name"><a href="#">Product Name Goes Here</a></h2>
                                        </div>
                                        <button class="cancel-btn"><i class="fa fa-trash"></i></button>
                                    </div>
                                </div>
                                <div class="shopping-cart-btns">
                                    <button class="main-btn">View Cart</button>
                                    <button class="primary-btn">Checkout <i class="fa fa-arrow-circle-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </li>
                    <!-- /Cart -->

                    <!-- Mobile nav toggle-->
                    <li class="nav-toggle">
                        <button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
                    </li>
                    <!-- / Mobile nav toggle -->
                </ul>
            </div>
        </div>
        <!-- header -->
    </div>
    <!-- container -->
</header>
<!-- /HEADER -->

<!-- NAVIGATION -->
<div id="navigation">
    <!-- container -->
    <div class="container">
        <div id="responsive-nav">
            <!-- category nav -->
            <div class="category-nav show-on-click">
                <a href="#"><span class="category-header">دسته بندی ها <i class="fa fa-list"></i></span></a>
                <ul class="category-list">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown side-dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">Jewelry & Watches <i class="fa fa-angle-right"></i></a>
                        <div class="custom-menu">
                            <div class="row">
                                <div class="col-md-4">
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                    <hr>
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                    <hr class="hidden-md hidden-lg">
                                </div>
                                <div class="col-md-4">
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                    <hr>
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                    <hr class="hidden-md hidden-lg">
                                </div>
                                <div class="col-md-4">
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                    <hr>
                                    <ul class="list-links">
                                        <li>
                                            <h3 class="list-links-title">Categories</h3></li>
                                        <li><a href="#">Women’s Clothing</a></li>
                                        <li><a href="#">Men’s Clothing</a></li>
                                        <li><a href="#">Phones & Accessories</a></li>
                                        <li><a href="#">Jewelry & Watches</a></li>
                                        <li><a href="#">Bags & Shoes</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a href="#">Bags & Shoes</a></li>
                    <li><a href="#">View All</a></li>
                </ul>
            </div>
            <!-- /category nav -->

            <!-- menu nav -->
            <div class="menu-nav" dir="rtl">
                <span class="menu-header">Menu <i class="fa fa-bars"></i></span>
                <ul class="menu-list">
                    <li><a href="<?php echo e(route('main')); ?>">خانه</a></li>
                    <li><a href="<?php echo e(route('categories')); ?>">دسته بندی ها</a></li>
                    <li class="dropdown default-dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">منوی کاربری <i class="fa fa-caret-down"></i></a>
                        <ul class="custom-menu">

                            <?php if(auth()->guard()->check()): ?>
                                <li><a href="<?php echo e(route('profile',auth::user()->id)); ?>">پنل کاربری</a></li>
                                <?php if(auth::user()->role== 1): ?>
                                    <li><a href="<?php echo e(route('admin.index')); ?>">پنل مدیریت</a></li>
                                <?php endif; ?>
                                <li>
                                    <form action="<?php echo e(route('logout')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-link" type="submit">خروج</button>
                                    </form>
                                </li>
                            <?php else: ?>
                                <li><a href="<?php echo e(route('register')); ?>">ثبت نام</a></li>
                                <li><a href="<?php echo e(route('login')); ?>">ورود</a></li>
                                
                            <?php endif; ?>
                        </ul>
                    </li>











































































































































                    <li><a href="<?php echo e(route('articles')); ?>">مطالب</a></li>
                    <li><a href="<?php echo e(route('contact')); ?>">تماس با ما</a></li>
                    <li><a href="<?php echo e(route('about')); ?>">درباره ما</a></li>





















                </ul>
            </div>
            <!-- menu nav -->
        </div>
    </div>
    <!-- /container -->
</div>
<script>
    function myFunction(){
        document.getElementById("myForm").submit();
    }
</script>
<?php /**PATH C:\xampp\laravel1\shop\resources\views/front/header.blade.php ENDPATH**/ ?>