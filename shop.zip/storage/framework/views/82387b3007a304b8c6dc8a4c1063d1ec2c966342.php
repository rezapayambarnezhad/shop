<?php $__env->startSection('title'); ?>

    ویرایش نظرات
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->
            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title"> ویرایش نظرات </h4>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <form class="forms-sample" action="<?php echo e(route('admin.comments.update',$comment->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputName1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php echo e($comment->name); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">email</label>
                                    <input type="text" class="form-control" id="exampleInputEmail3" name="email" value="<?php echo e($comment->email); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">محتوا</label>
                                    <textarea type="text" class="form-control" id="exampleInputEmail3" name="body" ><?php echo e($comment->body); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">status</label>
                                    <br>
                                    <select name="status" class="form-control" >
                                        <option value="0">منتشر نشده</option>
                                        <option value="1" <?php if ($comment->status==1) echo 'selected'?>>منتشر شده</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-success mr-2">edit</button>
                                <button class="btn btn-light">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/comments/edit.blade.php ENDPATH**/ ?>