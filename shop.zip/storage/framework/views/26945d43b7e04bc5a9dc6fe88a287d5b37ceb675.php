<?php $__env->startSection('content'); ?>
    <!-- BREADCRUMB -->
    <div id="breadcrumb">
        <div class="container">
            <ul class="breadcrumb" dir="rtl">
                <li><a href="#">منوی کاربری</a></li>
                <li class="active">دسته بندی ها</li>
            </ul>
        </div>
    </div>
    <!-- /BREADCRUMB -->

        <div class="row">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2" style="float: right ;margin: 3%;text-align: center" >
                    <h3><?php echo e($category->id); ?></h3><br>
                    <h3><a href="<?php echo e(route('category',$category->id)); ?>"><?php echo e($category->name); ?></a></h3><br>
                    <h3><?php echo e($category->slug); ?></h3><br>
                </div>











            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/front/categories.blade.php ENDPATH**/ ?>