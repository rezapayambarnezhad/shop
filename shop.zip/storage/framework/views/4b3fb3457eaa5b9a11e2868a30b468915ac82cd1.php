<?php $__env->startSection('content'); ?>
    <!-- BREADCRUMB -->
    <div id="breadcrumb">
        <div class="container">
            <ul class="breadcrumb" dir="rtl">
                <li><a href="#">منوی کاربری</a></li>
                <li class="active">دسته بندی ها</li>
                <li class="active"><?php echo e($category->name); ?></li>
            </ul>
        </div>
    </div>
    <!-- /BREADCRUMB -->

    <!-- section -->



    <?php $__currentLoopData = $category->articles()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($article->status==1): ?>
        <div class="col-md-2" style="float: right ;margin: 3%;text-align: center" >
            <img src="<?php echo '/storage/photos/1/'.basename($article->image) ?> " style="width: 200px;height: 200px">
            <p><?php echo e($article->user->name); ?></p><br>
            <p><?php echo e($article->user->created_at); ?></p><br>
            <h3><a href="<?php echo e(route('article',$article->id)); ?>"><?php echo e($article->name); ?></a> </h3>
            <p><?php echo substr(strip_tags( $article->desc),1,10). '...' ?></p>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/front/category.blade.php ENDPATH**/ ?>