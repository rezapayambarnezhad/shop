<?php $__env->startSection('title'); ?>

     نظرات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->
            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title">  نظرات </h4>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <form class="forms-sample">

                                <div class="form-group">
                                    <label for="exampleInputName1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php echo e($contact->name); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">email</label>
                                    <input type="text" class="form-control" id="exampleInputEmail3" name="email" value="<?php echo e($contact->email); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">محتوا</label>
                                    <textarea type="text" class="form-control" id="exampleInputEmail3" name="body" ><?php echo e($contact->body); ?></textarea>
                                </div>









                                <a href="<?php echo e(route('admin.contacts.destroy',$contact->id)); ?>"onclick=" return confirm('Delete entry?')" class="btn btn-danger btn-fw">delete</a>
                                <a href="<?php echo e(route('admin.contacts')); ?>" class="btn btn-success mr-2">Cancel</a>

                            </form>
                        </div>
                    </div>
                </div>
            </div>



        </div>
        <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/contacts/contact.blade.php ENDPATH**/ ?>