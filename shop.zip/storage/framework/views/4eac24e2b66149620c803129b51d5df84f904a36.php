<?php $__env->startSection('title'); ?>

    پنل مدیریت -مدیریت نظرات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->

            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title">پنل مدیریت -مدیریت نظرات</h4>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card-body">
                        <div class="template-demo">

                            <button type="button" class="btn btn-secondary btn-fw">Secondary</button>
                            <button type="button" class="btn btn-success btn-fw">Success</button>
                            <button type="button" class="btn btn-danger btn-fw">Danger</button>
                            <button type="button" class="btn btn-warning btn-fw">Warning</button>
                            <button type="button" class="btn btn-info btn-fw">Info</button>
                            <button type="button" class="btn btn-light btn-fw">Light</button>
                            <button type="button" class="btn btn-dark btn-fw">Dark</button>
                            <button type="button" class="btn btn-link btn-fw">Link</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('back.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>نویسنده</th>
                                <th>خلاصه نظرات</th>
                                <th>برای مطلب</th>
                                <th>باریخ مطلب</th>
                                <th>وضعیت</th>
                                <th>مدیریت</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($comment->status==1): ?>

                                    <?php
                                    $url=route('admin.comments-status',$comment->id);
                                        $status='<a href="'.$url.'"class="btn btn-success btn-fw">فعال<i class="far fa-eye"></i></a>'
                                    ?>
                                    <?php else: ?>
                                    <?php
                                        $url=route('admin.comments-status',$comment->id);
                                            $status='<a href="'.$url.'"class="btn btn-inverse-success btn-fw">غیر فال<i class="far fa-eye-slash"></i></a>'
                                    ?>
                                    <?php endif; ?>

                            <tr>
                                <td><?php echo e($comment->name); ?></td>
                                <td><?php echo mb_substr($comment->body,0,50); ?></td>
                                <td><?php echo e($comment->article->name); ?></td>
                                <td><?php echo jdate($comment->created_at)->format('%Y-%m-%d'); ?></td>
                                <td><?php echo $status; ?></td>

                                <td>
                                    <a href="<?php echo e(route('admin.comments.edit',$comment->id)); ?>"class="btn btn-success btn-md">edit <i class='far fa-edit'></i></a>
                                    <a href="<?php echo e(route('admin.comments.destroy',$comment->id)); ?>"onclick=" return confirm('Delete entry?')" class="btn btn-danger btn-md">del<i class='fas fa-trash-alt'></i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                        <?php echo e($comments->links()); ?>

                </div>
            </div>

            </div>

        </div>
        <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/comments/comments.blade.php ENDPATH**/ ?>