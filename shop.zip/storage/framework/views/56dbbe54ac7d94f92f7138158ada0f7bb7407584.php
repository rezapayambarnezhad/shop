<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>E-SHOP HTML Template</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
    <!-- Font Awesome Icon -->

    <link rel="stylesheet" href="<?php echo e(url('/font-awesome/css/font-awesome.min.css')); ?>">

    <link type="text/css" rel="stylesheet" href="<?php echo e(url('/front/css/app.css')); ?>" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
          <link href='http://www.fontonline.ir/css/BYekan.css' rel='stylesheet' type='text/css'>
          <link rel="stylesheet" type="text/css" href="http://font.limil.org/traffic.min.css"/>
          <link rel="stylesheet" type="text/css" href="http://font.limil.org/elham-traffic.min.css"/>
          <link rel="stylesheet" type="text/css" href="http://font.limil.org/elham-koodak.min.css"/>
          <link rel="stylesheet" type="text/css" href="http://font.limil.org/bardiya.min.css"/>
		<![endif]-->
    <?php echo htmlScriptTagJsApi(['lang'=>'en']); ?>
















</head>

<body>
	<!-- HEADER -->
<?php echo $__env->make('front.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /NAVIGATION -->


	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
                <?php echo $__env->yieldContent('content'); ?>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
<?php echo $__env->make('front.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
    <script src="<?php echo e(url('/front/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\laravel1\shop\resources\views/front/base.blade.php ENDPATH**/ ?>