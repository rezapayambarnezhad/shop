<?php $__env->startSection('title'); ?>

    دسته بندی جدید
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <!-- Page Title Header Starts-->
        <div class="row page-title-header">
            <div class="col-12">
                <div class="page-header">
                    <h4 class="page-title"> دسته بندی جدید</h4>
                </div>
            </div>

        </div>
       <div class="row">
           <div class="col-md-6 grid-margin stretch-card">
               <div class="card">
                   <div class="card-body">
                       <form class="forms-sample" action="<?php echo e(route('admin.categories.store')); ?>" method="post">
                           <?php echo csrf_field(); ?>
                           <div class="form-group">
                               <label for="exampleInputName1">Name</label>
                               <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php echo e(old('name')); ?>" >
                           </div>
                           <div class="form-group">
                               <label for="exampleInputEmail3">slug</label>
                               <input type="text" class="form-control" id="exampleInputEmail3" name="slug" value="<?php echo e(old('slug')); ?>">
                           </div>

                           <button type="submit" class="btn btn-success mr-2">Create</button>
                           <button class="btn btn-light">Cancel</button>
                       </form>
                   </div>
               </div>
           </div>
       </div>



    </div>
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/categories/create.blade.php ENDPATH**/ ?>