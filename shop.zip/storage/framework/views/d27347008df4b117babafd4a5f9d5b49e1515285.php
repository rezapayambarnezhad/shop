<?php $__env->startSection('title'); ?>

    ویرایش مطلب
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->
            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title">ویرایش مطلب </h4>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <form class="forms-sample" action="<?php echo e(route('admin.articles.update',$article->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="exampleInputName1">Name</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="name" value="<?php echo e($article->name); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputName1">قیمت</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="main_price" value="<?php echo e($article->main_price); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputName1">تخفیف</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="suggest_price" value="<?php echo e($article->suggest_price); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputName1">اف</label>
                                    <input type="text" class="form-control" id="exampleInputName1" name="off_price" value="<?php echo e($article->off_price); ?>" >
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">slug</label>
                                    <input type="text" class="form-control" id="exampleInputEmail3" name="slug" value="<?php echo e($article->slug); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">محتوا</label>
                                    <textarea type="text" class="form-control" id="exampleInputEmail3" name="desc" ><?php echo e($article->desc); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">نویسنده:<?php echo e(Auth::user()->name); ?></label>
                                    <input type="hidden"  name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                </div>

                                <div class="form-group">
                                    <label for="exampleInputEmail3">status</label>
                                    <br>
                                    <select name="status" class="form-control" >
                                        <option value="0">منتشر نشده</option>
                                        <option value="1" <?php if ($article->status==1) echo 'selected'?>>منتشر شده</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputEmail3">chosen</label><br>
                                    <div id="output"></div>
                                    <select class="test_mull form-control" name="categories[]" multiple >
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>" <?php if (in_array($category->id,$article->categories->pluck('id')->toarray())) echo 'selected' ?> ><?php echo e($category->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="input-group">
                                  <span class="input-group-btn">
                                  <a href="#" id="lfm" data-input="image" data-preview="holder" class="btn btn-primary">
                                       <i class="fa fa-picture-o"></i> انتخاب عکس
                                  </a>
                                  </span>
                                    <input id="image" class="form-control" type="text" name="image" value="<?php echo e($article->image); ?>">
                                </div>
                                <div class="input-group" style="margin-bottom: 3%">
                                <img id="holder" style="margin-top:15px;max-height:100px;" src="<?php echo e($article->image); ?>">
                                </div>
                                <button type="submit" class="btn btn-success mr-2">Create</button>
                                <button class="btn btn-light">Cancel</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/articles/edit.blade.php ENDPATH**/ ?>