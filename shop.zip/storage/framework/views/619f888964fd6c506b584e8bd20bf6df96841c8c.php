<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title><?php echo $__env->yieldContent('title'); ?></title>
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/iconfonts/mdi/css/materialdesignicons.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/iconfonts/ionicons/css/ionicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/iconfonts/typicons/src/font/typicons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/iconfonts/flag-icon-css/css/flag-icon.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/vendors/css/vendor.bundle.addons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/css/shared/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('/assets/css/demo_1/style.css')); ?>">
  <link rel="shortcut icon" href="<?php echo e(url('/assets/images/favicon.png')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/assets/chosen/chosen.css')); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">






    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>

    <script>
        var editor_config = {
            path_absolute : "/",
            selector: "textarea#editor",
            directionality:"rtl",
            plugins: [
                "directionality advlist autolink lists link image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime media nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media | ltr rtl",
            relative_urls: false,
            file_browser_callback : function(field_name, url, type, win) {
                var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
                var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

                var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
                if (type == 'image') {
                    cmsURL = cmsURL + "&type=Images";
                } else {
                    cmsURL = cmsURL + "&type=Files";
                }

                tinyMCE.activeEditor.windowManager.open({
                    file : cmsURL,
                    title : 'Filemanager',
                    width : x * 0.8,
                    height : y * 0.8,
                    resizable : "yes",
                    close_previous : "no"
                });
            }
        };

        tinymce.init(editor_config);
    </script>
</head>
<body style="font-family: p30">
  <div class="container-scroller">

    <?php echo $__env->make('back.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container-fluid page-body-wrapper">

      <?php echo $__env->make('back.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



            <?php echo $__env->yieldContent('content'); ?>



    </div>

  </div>
  <script src="<?php echo e(url('/assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/vendors/js/vendor.bundle.addons.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/shared/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/shared/misc.js')); ?>"></script>
  <script src="<?php echo e(url('/assets/js/demo_1/dashboard.js')); ?>"></script>
  <!-- End custom js for this page-->
  <script type="text/javascript" src="<?php echo e(url('/assets/chosen/chosen.jquery.js')); ?>"></script>

<script>
    <?php echo \File::get(base_path('vendor/unisharp/laravel-filemanager/public/js/stand-alone-button.js')); ?>;
    $('#lfm').filemanager('image');
</script>




  <script>
      $(document).ready(function () {
          $(".test").chosen();
          $(".test_mull").chosen();

      })

  </script>

</body>

</html>
<?php /**PATH C:\xampp\laravel1\shop\resources\views/back/index.blade.php ENDPATH**/ ?>