<?php if(session('success')): ?>
<div class="alert alert-success" dir="rtl">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\xampp\laravel1\shop\resources\views/back/massage.blade.php ENDPATH**/ ?>