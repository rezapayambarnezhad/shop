<?php $__env->startSection('title'); ?>

    پنل مدیریت -مدیریت مطالب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->

            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title">پنل مدیریت -مدیریت مطالب</h4>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="card-body">
                        <div class="template-demo">
                            <a href="<?php echo e(route('admin.articles.create')); ?>" type="button" class="btn btn-primary btn-fw">مطلب جدید</a>
                            <button type="button" class="btn btn-secondary btn-fw">Secondary</button>
                            <button type="button" class="btn btn-success btn-fw">Success</button>
                            <button type="button" class="btn btn-danger btn-fw">Danger</button>
                            <button type="button" class="btn btn-warning btn-fw">Warning</button>
                            <button type="button" class="btn btn-info btn-fw">Info</button>
                            <button type="button" class="btn btn-light btn-fw">Light</button>
                            <button type="button" class="btn btn-dark btn-fw">Dark</button>
                            <button type="button" class="btn btn-link btn-fw">Link</button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('back.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ردیف</th>
                                <th>نام</th>
                                <th>قیمت</th>
                                <th>تخفیف</th>
                                <th>اف</th>
                                <th>نام مستعار-slug</th>
                                <th>نویسنده</th>
                                <th>دسته بندی</th>
                                <th>بازدید</th>
                                <th>وضعیت</th>
                                <th>پیشنهاد</th>
                                <th>مدیریت</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($article->status==1): ?>

                                    <?php
                                    $url=route('admin.article-status',$article->id);
                                        $status='<a href="'.$url.'"class="btn btn-success btn-fw">فعال<i class="far fa-eye"></i></a>'
                                    ?>
                                    <?php else: ?>
                                    <?php
                                        $url=route('admin.article-status',$article->id);
                                            $status='<a href="'.$url.'"class="btn btn-inverse-success btn-fw">غیر فال<i class="far fa-eye-slash"></i></a>'
                                    ?>
                                    <?php endif; ?>
                                <?php if($article->suggestion==1): ?>

                                    <?php
                                        $url=route('admin.article-test',$article->id);
                                            $suggestion='<a href="'.$url.'"class="btn btn-info btn-fw">ویژه<i class="far fa-eye"></i></a>'
                                    ?>
                                <?php else: ?>
                                    <?php
                                        $url=route('admin.article-test',$article->id);
                                            $suggestion='<a href="'.$url.'"class="btn btn-inverse-info btn-fw">نرمال<i class="far fa-eye-slash"></i></a>'
                                    ?>
                                <?php endif; ?>


                            <tr>
                                <td><?php echo e($article->id); ?></td>
                                <td><?php echo e($article->name); ?></td>
                                <td><?php echo e($article->main_price); ?></td>
                                <td><?php echo e($article->suggest_price); ?></td>
                                <td><?php echo e($article->off_price); ?></td>
                                <td><?php echo e($article->slug); ?></td>
                                <td><?php echo e($article->user->name); ?></td>
                                <td>
                                    <?php $__currentLoopData = $article->categories()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <span class="badge badge-warning"> <?php echo e($category->name); ?> </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($article->hit); ?></td>
                                <td><?php echo $status; ?></td>
                                <td>



























                                    <?php echo $suggestion; ?>


                                </td>




                                <td>
                                    <a href="<?php echo e(route('admin.articles.edit',$article->id)); ?>"  class="btn btn-success btn-md">edit <i class='far fa-edit'></i></a>


                                    <a href="<?php echo e(route('admin.articles.destroy',$article->id)); ?>"onclick=" return confirm('Delete entry?')" class="btn btn-danger btn-md">del<i class='fas fa-trash-alt'></i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                        <?php echo e($articles->links()); ?>

                </div>
            </div>

            </div>

        </div>






        <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/articles/articles.blade.php ENDPATH**/ ?>