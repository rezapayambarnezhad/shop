<?php $__env->startSection('title'); ?>

    پنل مدیریت -مدیریت کاربران
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <!-- Page Title Header Starts-->
            <div class="row page-title-header">
                <div class="col-12">
                    <div class="page-header">
                        <h4 class="page-title">پنل مدیریت-کاربران</h4>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <?php echo $__env->make('back.massage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>ردیف</th>
                                <th>نام</th>
                                <th>ایمیل</th>
                                <th>تلفن</th>
                                <th>نقش</th>
                                <th>وضعیت</th>
                                <th>مدیریت</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->role==1): ?>
                                    <?php $role='مدیر' ?>
                                    <?php else: ?>
                                    <?php $role='کاربر' ?>
                                <?php endif; ?>
                                <?php if($user->status==1): ?>

                                    <?php
                                        $url= route('admin.profile-status',$user->id);
                                    $status='<a href="'.$url.'"class="btn btn-success btn-fw">فعال<i class="far fa-eye"></i></a>'?>
                                <?php else: ?>

                                    <?php
                                        $url= route('admin.profile-status',$user->id);
                                        $status='<a href="'.$url.'"class="btn btn-inverse-success btn-fw">غیر فال<i class="far fa-eye-slash"></i></a>'  ?>
                                <?php endif; ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($role); ?></td>
                                <td><?php echo $status; ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.profile',$user->id)); ?>" class="btn btn-success btn-md">edit <i class='far fa-edit'></i></a>
                                    <a href="<?php echo e(route('admin.profile-delete',$user->id)); ?>"onclick=" return confirm('Delete entry?')" class="btn btn-danger btn-md">del<i class='fas fa-trash-alt'></i></a>
                                </td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </tbody>
                        </table>
                    </div>
                        <?php echo e($users->links()); ?>

                </div>
            </div>

            </div>

        </div>
        <?php echo $__env->make('back.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('back.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\laravel1\shop\resources\views/back/users/users.blade.php ENDPATH**/ ?>